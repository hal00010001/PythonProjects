#!/usr/bin/python3
#coding: utf-8
br = float(input('Digite quantos reais voce quer trocar por dolar:\n'))
print('Voce pode comprar {} dolares'.format(br * 4.08))
