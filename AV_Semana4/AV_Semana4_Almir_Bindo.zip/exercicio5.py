#!/usr/bin/python3
#coding: utf-8
numero = int(input('Digite um numero inteiro:\n'))
if(numero % 2 == 0):
    print('O numero digitado e par')
else:
    print('O numero digitado e impar')
